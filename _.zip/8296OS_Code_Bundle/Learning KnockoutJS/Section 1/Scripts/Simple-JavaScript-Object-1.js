﻿var obj = new Object();
obj.publisher = "Packt Publishing";
obj.title = "Learning Knockout.JS";
obj.author = "Robert Gaut";

// The following is not allowed
//var obj2 = new obj();