﻿var obj = {
    publisher: "Packt Publishing",
    title: "Learning Knockout.JS",
    author: "Robert Gaut"
};

// The following is not allowed
//var obj2 = new obj();