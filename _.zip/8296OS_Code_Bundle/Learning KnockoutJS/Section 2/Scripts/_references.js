﻿/// <autosync enabled="true" />
/// <reference path="datacontext.js" />
/// <reference path="jquery-2.1.4.js" />
/// <reference path="knockout-3.3.0.js" />
/// <reference path="models/media.js" />
/// <reference path="viewmodels/defaultviewmodel.js" />
